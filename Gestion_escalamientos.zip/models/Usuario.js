const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema({
  nombre: { type: String, required: true },
  CI: { type: String, required: true, unique: true },
  telefono: { type: String, required: true },
  departamento: { type: String, required: true },
  email: { type: String, lowercase: true },
  activo: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Usuario', usuarioSchema);