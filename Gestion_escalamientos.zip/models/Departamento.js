const mongoose = require('mongoose');

const departamentoSchema = new mongoose.Schema({
  codigo: { type: String, required: true, unique: true },
  nombre: { type: String, required: true },
  responsable: { type: String, required: true },
  extension: { type: String, required: true },
  ubicacion: String,
  activo: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Departamento', departamentoSchema);