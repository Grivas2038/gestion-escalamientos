const mongoose = require('mongoose');

const configuracionSchema = new mongoose.Schema({
  clave: { type: String, required: true, unique: true },
  valor: { type: String, required: true },
  descripcion: { type: String, required: true },
  activo: { type: Boolean, default: true },
  modificable: { type: Boolean, default: true }
}, { timestamps: true });

module.exports = mongoose.model('Configuracion', configuracionSchema);