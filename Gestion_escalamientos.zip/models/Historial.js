const mongoose = require('mongoose');

const historialSchema = new mongoose.Schema({
  ticket_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Ticket', required: true },
  fecha_accion: { type: Date, default: Date.now },
  accion: { type: String, required: true },
  usuario: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario' },
  detalle: String
}, { timestamps: true });

module.exports = mongoose.model('Historial', historialSchema);