const mongoose = require('mongoose');

const ticketSchema = new mongoose.Schema({
  numero_ticket: { type: String, required: true, unique: true },
  fecha_escalamiento: { type: Date, default: Date.now },
  fecha_cierre: Date,
  dias_impacto: { type: Number, default: 0 },
  estatus: { type: String, enum: ['Abierto', 'En Proceso', 'Resuelto', 'Cerrado'], default: 'Abierto' },
  area_escalamiento: String,
  descripcion: String,
  solicitante: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario' }
}, { timestamps: true });

module.exports = mongoose.model('Ticket', ticketSchema);