const express = require('express');
const router = express.Router();
const Departamento = require('../models/Departamento');


router.post('/', async (req, res) => {
  try {
    const nuevo = new Departamento(req.body);
    await nuevo.save();
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


router.get('/', async (req, res) => {
  try {
    const departamentos = await Departamento.find();
    res.json(departamentos);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.get('/:id', async (req, res) => {
  try {
    const dept = await Departamento.findById(req.params.id);
    if (!dept) return res.status(404).json({ mensaje: 'Departamento no encontrado' });
    res.json(dept);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.put('/:id', async (req, res) => {
  try {
    const dept = await Departamento.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!dept) return res.status(404).json({ mensaje: 'Departamento no encontrado' });
    res.json(dept);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const dept = await Departamento.findByIdAndDelete(req.params.id);
    if (!dept) return res.status(404).json({ mensaje: 'Departamento no encontrado' });
    res.json({ mensaje: 'Departamento eliminado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// CONSULTA SENCILLA: buscar por responsable
router.get('/consulta/responsable/:nombre', async (req, res) => {
  try {
    const depts = await Departamento.find({ responsable: { $regex: req.params.nombre, $options: 'i' } });
    res.json(depts);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;