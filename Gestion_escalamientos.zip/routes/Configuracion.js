const express = require('express');
const router = express.Router();
const Configuracion = require('../models/Configuracion');


router.post('/', async (req, res) => {
  try {
    const nueva = new Configuracion(req.body);
    await nueva.save();
    res.status(201).json(nueva);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


router.get('/', async (req, res) => {
  try {
    const configs = await Configuracion.find();
    res.json(configs);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.get('/:id', async (req, res) => {
  try {
    const config = await Configuracion.findById(req.params.id);
    if (!config) return res.status(404).json({ mensaje: 'Configuración no encontrada' });
    res.json(config);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.put('/:id', async (req, res) => {
  try {
    const config = await Configuracion.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!config) return res.status(404).json({ mensaje: 'Configuración no encontrada' });
    res.json(config);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const config = await Configuracion.findByIdAndDelete(req.params.id);
    if (!config) return res.status(404).json({ mensaje: 'Configuración no encontrada' });
    res.json({ mensaje: 'Configuración eliminada' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// CONSULTA SENCILLA: buscar por clave
router.get('/consulta/clave/:clave', async (req, res) => {
  try {
    const config = await Configuracion.findOne({ clave: req.params.clave });
    if (!config) return res.status(404).json({ mensaje: 'Clave no encontrada' });
    res.json(config);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;