const express = require('express');
const router = express.Router();
const Historial = require('../models/Historial');


router.post('/', async (req, res) => {
  try {
    const nuevo = new Historial(req.body);
    await nuevo.save();
    res.status(201).json(nuevo);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


router.get('/', async (req, res) => {
  try {
    const registros = await Historial.find()
      .populate('ticket_id', 'numero_ticket estatus')
      .populate('usuario', 'nombre CI');
    res.json(registros);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.get('/:id', async (req, res) => {
  try {
    const registro = await Historial.findById(req.params.id)
      .populate('ticket_id', 'numero_ticket estatus')
      .populate('usuario', 'nombre');
    if (!registro) return res.status(404).json({ mensaje: 'Registro no encontrado' });
    res.json(registro);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.put('/:id', async (req, res) => {
  try {
    const registro = await Historial.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!registro) return res.status(404).json({ mensaje: 'Registro no encontrado' });
    res.json(registro);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const registro = await Historial.findByIdAndDelete(req.params.id);
    if (!registro) return res.status(404).json({ mensaje: 'Registro no encontrado' });
    res.json({ mensaje: 'Registro eliminado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// CONSULTA SENCILLA: historial de un ticket específico
router.get('/consulta/ticket/:ticketId', async (req, res) => {
  try {
    const registros = await Historial.find({ ticket_id: req.params.ticketId })
      .populate('usuario', 'nombre');
    res.json(registros);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;