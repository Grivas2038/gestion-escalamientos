const express = require('express');
const router = express.Router();
const Ticket = require('../models/Ticket');


router.post('/', async (req, res) => {
  try {
    const nuevoTicket = new Ticket(req.body);
    await nuevoTicket.save();
    res.status(201).json(nuevoTicket);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


router.get('/', async (req, res) => {
  try {
    const tickets = await Ticket.find().populate('solicitante');
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.get('/:id', async (req, res) => {
  try {
    const ticket = await Ticket.findById(req.params.id);
    if (!ticket) return res.status(404).json({ mensaje: 'Ticket no encontrado' });
    res.json(ticket);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


router.put('/:id', async (req, res) => {
  try {
    const ticket = await Ticket.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!ticket) return res.status(404).json({ mensaje: 'Ticket no encontrado' });
    res.json(ticket);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});


router.delete('/:id', async (req, res) => {
  try {
    const ticket = await Ticket.findByIdAndDelete(req.params.id);
    if (!ticket) return res.status(404).json({ mensaje: 'Ticket no encontrado' });
    res.json({ mensaje: 'Ticket eliminado' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// CONSULTA SENCILLA: tickets por estatus
router.get('/consulta/estatus/:estatus', async (req, res) => {
  try {
    const tickets = await Ticket.find({ estatus: req.params.estatus });
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;