const mongoose = require('mongoose');
require('dotenv').config();

const Ticket = require('./models/Ticket');
const Usuario = require('./models/Usuario');
// ... importa los demás modelos

mongoose.connect(process.env.MONGODB_URI)
  .then(async () => {
    console.log('Conectado para insertar semilla...');
    // Limpia colecciones (opcional)
    await Ticket.deleteMany({});
    await Usuario.deleteMany({});
    // Crea documentos de ejemplo
    const usuario1 = await Usuario.create({ nombre: 'Juan Pérez', CI: '12345678', telefono: '+584141234567', departamento: 'Sistemas' });
    await Ticket.create([
      { numero_ticket: 'T-001', area_escalamiento: 'Soporte', estatus: 'Abierto', solicitante: usuario1._id },
      { numero_ticket: 'T-002', area_escalamiento: 'Redes', estatus: 'Cerrado' }
    ]);
    console.log('Semilla insertada');
    process.exit();
  })
  .catch(err => { console.error(err); process.exit(1); });