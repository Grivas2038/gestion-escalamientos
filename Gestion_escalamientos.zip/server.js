const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();


app.use(cors());
app.use(express.json());


mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log('✅ Conectado a MongoDB'))
  .catch(err => console.error('❌ Error de conexión:', err));

app.use('/api/tickets', require('./routes/tickets'));
app.use('/api/usuarios', require('./routes/usuarios'));
app.use('/api/departamentos', require('./routes/departamentos'));
app.use('/api/historial', require('./routes/historial'));
app.use('/api/configuracion', require('./routes/configuracion'));


app.get('/', (req, res) => {
  res.send('API de Gestión de Escalamientos');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor corriendo en puerto ${PORT}`));